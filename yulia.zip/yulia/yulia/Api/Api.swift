
import Alamofire
import Foundation

class Network {
    
    private init() {}
    static let shared = Network()
    
    func logIn(parameters:[String:String],completion: @escaping (Result<Bool,NetworkError>)->Void) {
        AF.request("https://warm-lake-90646.herokuapp.com/api/v1/auth/login", method: .post,parameters: parameters,encoding: JSONEncoding.default).validate(statusCode: 200..<201).responseData { (response) in
            print(parameters)
            switch response.result {
            case .success(let userData):
                do {
                    let user = try JSONDecoder().decode(UserLogIn.self, from: userData)
                    Constants.globalToken = user.token
                    completion(.success(true))
                } catch  {
                    completion(.failure(NetworkError.logInError))
                }
            case .failure(_):
                switch response.response?.statusCode {
                case 403:
                    completion(.failure(NetworkError.noSuchUser))
                default:
                    completion(.failure(NetworkError.problemWithBack))
                }
                
            }
        }
    }
    
    
    
    func getCurrentUser(completion: @escaping (Result<User,NetworkError>)->Void) {
        guard let token = Constants.globalToken else {return}
        let header: HTTPHeaders = ["Authorization":"Bearer_\(token)"]
        AF.request("https://warm-lake-90646.herokuapp.com/api/v1/users/current",headers: header).validate(statusCode: 200..<201).responseData { (response) in
            switch response.result {
            case .success(let userCurrentData):
                do {
                    let user = try JSONDecoder().decode(User.self, from: userCurrentData)
                    completion(.success(user))
                } catch  {
                    completion(.failure(NetworkError.currentUser))
                }
            case .failure(_):
                completion(.failure(NetworkError.problemWithBack))
            }
        }
        
    }
    
    func getCultures(completion: @escaping (Result<[Culture],NetworkError>)->Void) {
        guard let token = Constants.globalToken else {return}
        let header: HTTPHeaders = ["Authorization":"Bearer_\(token)"]
        AF.request("https://warm-lake-90646.herokuapp.com/api/v1/cultures", headers: header).validate(statusCode: 200..<201).responseData { (response) in
            switch response.result {
            case .success(let culturesData):
                do {
                    let cultureDict = try JSONDecoder().decode([Culture].self, from: culturesData)
                    completion(.success(cultureDict))
                } catch  {
                    completion(.failure(NetworkError.cultures))
                }
            case .failure(let error):
                print(error.localizedDescription)
                completion(.failure(NetworkError.problemWithBack))
            }
            
        }
    }
    
    func getMyProject(completion: @escaping (Result<Project,NetworkError>) -> Void){
         guard let token = Constants.globalToken else {return}
        let header: HTTPHeaders = ["Authorization":"Bearer_\(token)"]
        AF.request("https://warm-lake-90646.herokuapp.com/api/v1/project/current/manager", headers: header).validate(statusCode: 200..<201).responseData { response in
            switch response.result {
            case .success(let projectData):
                do {
                    let project = try JSONDecoder().decode(Project.self, from: projectData)
                    completion(.success(project))
                } catch  {
                    completion(.failure(NetworkError.project))
                }
            case .failure(_):
                guard let status = response.response?.statusCode else {return}
                if status == 404 {
                    completion(.failure(NetworkError.project))
                }
                completion(.failure(NetworkError.noProject))
            }
            
        }
       
    }
    
    
    func getProjectCultures(completion: @escaping (Result<[Culture],NetworkError>) -> Void){
        guard let token = Constants.globalToken else {return}
        let header: HTTPHeaders = ["Authorization":"Bearer_\(token)"]
        AF.request("https://warm-lake-90646.herokuapp.com/api/v1/project/current/manager", headers: header).validate(statusCode: 200..<201).responseData { response in
            switch response.result {
            case .success(let projectData):
                do {
                    let project = try JSONSerialization.jsonObject(with: projectData, options: .allowFragments) as? [String: Any]
                    let cultures = project?["cultures"] as? [[String:Any]]
                    var cultArr = [Culture]()
                    guard let myCultures = cultures else {completion(.failure(NetworkError.noCulture));return}
                    for cult in myCultures{
                        if let name = cult["name"] as? String, let plantDivision = cult["plantDivision"] as? String, let project = cult["project"] as? Int, let description = cult["description"] as? String{
                            let structCulture = Culture(name: name, description: description, plantDivision: plantDivision, project: project)
                            cultArr.append(structCulture)
                        }
                        
                    }
                    completion(.success(cultArr))
                } catch  {
                    completion(.failure(NetworkError.project))
                }
            case .failure(_):
                guard let status = response.response?.statusCode else {return}
                if status == 404 {
                    completion(.failure(NetworkError.project))
                }
                completion(.failure(NetworkError.noProject))
            }
            
        }
        
    }
    
    func getAreas(completion: @escaping (Result<[Area],NetworkError>) -> Void) {
        guard let token = Constants.globalToken else {return}
        let header: HTTPHeaders = ["Authorization":"Bearer_\(token)"]
        AF.request("https://warm-lake-90646.herokuapp.com/api/v1/project/current/manager", headers: header).validate(statusCode: 200..<201).responseData { response in
             print( response.response?.statusCode)
            switch response.result {
            case .success(let areasData):
                do {
                    let project = try JSONSerialization.jsonObject(with: areasData, options: .allowFragments) as? [String: Any]
                    let areas = project?["testAreas"] as? [[String:Any]]
                  var areaArr = [Area]()
                    guard let myAreas = areas else {completion(.failure(NetworkError.noArea));return}
                    for area in myAreas{
                        if let created = area["created"] as? Int, let description = area["description"] as? String, let culture = area["culture"] as? [String:Any], let  observationData = area["observationData"] as? String,let cultureName = culture["name"] as? String {
                           let returnArea = Area(created: created , description: description, culture: cultureName , observationData: observationData)
                            areaArr.append(returnArea)
                            print("appended")
                        }
                        
                    }
                    print(areaArr)
                    print("append")
                    completion(.success(areaArr))
                } catch  {
                    
                    completion(.failure(NetworkError.noArea))
                }
            case .failure(_):
                guard let status = response.response?.statusCode else {return}
               
                if status == 404 {
                    completion(.failure(NetworkError.noArea))
                } else {
                    completion(.failure(NetworkError.problemWithBack))
                }
                
            }
            
        }
    }
    
    
}
