

import Foundation
enum NetworkError: Error {
    case logInError
    case problemWithBack
    case noSuchUser
    case currentUser
    case cultures
    case project
    case testAreas
    case noProject
    case noCulture
    case noArea
    var description: String {
        switch self {
        case .logInError:
            return "An error in log in"
        case .problemWithBack:
            return "Connection with back failed"
        case .noSuchUser:
            return "No such user"
        case .currentUser:
            return "Can not load user"
        case .cultures:
            return "Can not load cultures"
        case .project:
            return "Can not load my project"
        case .testAreas:
            return "Can not load test areas"
        case .noProject:
            return "No projects"
        case .noCulture:
            return "No cultures for this project"
        case .noArea :
           return  "No test areas for this project"
        }
    }
}
