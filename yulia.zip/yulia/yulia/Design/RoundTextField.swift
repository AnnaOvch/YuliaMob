import UIKit

extension UITextField {
    @IBInspectable var cornerRadius: CGFloat {
        get{
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
        }
    }
    
     @IBInspectable var leftPadding: CGFloat {
           get {
               return (self.leftView?.frame.width)!
           }
           set {
               let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: newValue, height: self.frame.size.height))
               self.leftView = paddingView
               self.leftViewMode = .always
           }
       }
}
