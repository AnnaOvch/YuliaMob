
import UIKit

class CulturesTableViewController: UITableViewController {

    var cultrures:[Culture]?
    
     let activityView = UIActivityIndicatorView(style: .medium)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let nib = UINib(nibName: "CultureTableViewCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "cultureCell")
        tableView.allowsSelection = false
        tableView.separatorStyle = .none
        getCultures()
      }
    

 
}
extension CulturesTableViewController {

    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        if let count = cultrures?.count {
            return 1
        } else {
            return 0 
        }
        
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.cultrures?.count ?? 0
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 131.0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "cultureCell") as! CultureTableViewCell
        let culture = self.cultrures![indexPath.row]
        cell.configure(culture: culture)
        return cell
    }
    
    
     func getCultures() {
        self.showActivityIndicatory(actView: activityView)
         Network.shared.getCultures {[weak self] (result) in
            switch result {
            case .success(let culturesArr):
                DispatchQueue.main.async {
                    self?.cultrures = culturesArr
                    self?.tableView.reloadData()
                    self?.hideActivityIndicator(actView: self!.activityView)
                }
             case .failure(let error):
                DispatchQueue.main.async {
                    self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                    self?.tableView.reloadData()
                    self?.hideActivityIndicator(actView: self!.activityView)
                 }
             }
         }
     }
}
