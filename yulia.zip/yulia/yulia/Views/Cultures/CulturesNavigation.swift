//
import UIKit

class CulturesNavigation: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

}
