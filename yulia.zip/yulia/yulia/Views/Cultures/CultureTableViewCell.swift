
import UIKit

class CultureTableViewCell: UITableViewCell {

    @IBOutlet weak var projectIdLabel: UILabel!
    @IBOutlet weak var plantDivisionLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func configure(culture: Culture) {
        print(culture)
        self.nameLabel.text = culture.name
        self.descriptionLabel.text = culture.description
        self.plantDivisionLabel.text = culture.plantDivision
        self.projectIdLabel.text = String(culture.project)
    }
   
    
}
