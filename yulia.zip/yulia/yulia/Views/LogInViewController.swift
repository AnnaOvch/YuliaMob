
import UIKit

class LogInViewController: UIViewController {
    
    @IBOutlet weak var usernameTextField: UITextField!

    @IBOutlet weak var passwordTextField: UITextField!
    
    let activityView = UIActivityIndicatorView(style: .medium)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    @IBAction func loginButton(_ sender: Any) {
        if usernameTextField.text?.isEmpty == true || passwordTextField.text?.isEmpty == true {
            self.showAlert(alertText: "All fields must be filled", alertAction: "ok", handler: nil)
        } else {
                if passwordTextField.text?.count ?? 0 < 6 {
                self.showAlert(alertText: "Password must contain at least 6 characters", alertAction: "ok", handler: nil)
                
            } else {
                    self.showActivityIndicatory(actView: activityView)
                    let parameters = ["username":usernameTextField.text!,"password":passwordTextField.text!]
                    Network.shared.logIn(parameters: parameters) { [weak self] (result) in
                        switch result {
                        case .success(let myBool):
                            DispatchQueue.main.async {
                                self?.hideActivityIndicator(actView: self!.activityView)
                                let vc = TabBarController.instance()
                                self?.present(vc,animated:true)
                            }
                        case .failure(let error):
                            self?.hideActivityIndicator(actView: self!.activityView)
                            self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                        }
                    }
            }
        }
    }
    
    private func validateEmail(candidate: String) -> Bool {
     let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: candidate)
    }
    

}

extension LogInViewController: StoryboardLoadable, UITextFieldDelegate {
    static var storyboardName: String {
       return "Main"
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
}
