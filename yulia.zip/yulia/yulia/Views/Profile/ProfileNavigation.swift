
import UIKit

class ProfileNavigation: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

}
