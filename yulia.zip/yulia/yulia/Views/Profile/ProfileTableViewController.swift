
import UIKit

class ProfileTableViewController: UITableViewController {
    
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var firstNameLabel: UILabel!
    @IBOutlet weak var lastNameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var registrationDateLabel: UILabel!
    @IBOutlet weak var adminRootsLabel: UILabel!
    
    let activityView = UIActivityIndicatorView(style: .medium)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        downloadProfileFromBack()
        tableView.allowsSelection = false
        
    }
    
    @IBAction func logOutButton(_ sender: Any) {
        let vc = LogInViewController.instance()
        vc.modalPresentationStyle = .fullScreen
        Constants.globalToken = nil
        self.present(vc,animated: false)
        
    }
    
 
}

extension ProfileTableViewController {
    func downloadProfileFromBack() {
        self.showActivityIndicatory(actView: activityView)
        Network.shared.getCurrentUser {[weak self] (result) in
            switch result {
            case .success(let user):
                DispatchQueue.main.async {
                    self?.idLabel.text = String(user.id)
                    self?.usernameLabel.text = user.username
                    self?.firstNameLabel.text = user.firstName
                    self?.lastNameLabel.text = user.lastName
                    self?.emailLabel.text = user.email
                    
                    self?.registrationDateLabel.text = self?.dateFromTimestamp(time: user.registrationDate)
                    self?.adminRootsLabel.text = user.admin == true ? "You have admin roots" : "You do not have admin roots"
                    self?.hideActivityIndicator(actView: self!.activityView)
                    
                }
            case .failure(let error):
                DispatchQueue.main.async {
                     self?.hideActivityIndicator(actView: self!.activityView)
                    self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                    self?.tableView.setEmptyView(title: "No profile", message: "Try later")
                }
            }
        }
    }
    func dateFromTimestamp(time: Int)->String {
        let time = Double(time)/1000.0
        let myDate = NSDate(timeIntervalSince1970: time)
        
        let dayTimePeriodFormatter = DateFormatter()
        dayTimePeriodFormatter.dateFormat = "MMM dd YYYY hh:mm a"
        dayTimePeriodFormatter.timeZone = NSTimeZone(name: "UTC") as TimeZone?
        
        let dateString = dayTimePeriodFormatter.string(from: myDate as Date)
        return dateString
    }
    
   
}
