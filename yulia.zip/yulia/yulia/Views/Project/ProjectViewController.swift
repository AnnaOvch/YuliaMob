

import UIKit

class ProjectViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var createdLabel: UILabel!
    
    @IBOutlet weak var testButton: UIButton! {
        didSet {
            testButton.layer.cornerRadius = testButton.frame.height/2
        }
    }
    @IBOutlet weak var culturesButton: UIButton! {
        didSet {
            culturesButton.layer.cornerRadius = culturesButton.frame.height/2
        }
    }
    
    
    var myProject: Project?
    
    let activityView = UIActivityIndicatorView(style: .medium)
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getProjectFromBack()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        print("view did load")
        //getProjectFromBack()
        

    }
    
    @IBAction func tstAreasButton(_ sender: Any) {
    }
    @IBAction func culturesButton(_ sender: Any) {
    }
    
}

extension ProjectViewController {
    func getProjectFromBack() {
        self.showActivityIndicatory(actView: activityView)
        Network.shared.getMyProject {[weak self] (result) in
            switch result {
            case .success(let project):
                DispatchQueue.main.async {
                    self?.myProject = project
                    self?.nameLabel.text = project.name
                    self?.createdLabel.text =  self?.dateFromTimestamp(time: project.created)
                    self?.hideActivityIndicator(actView: self!.activityView)
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    self?.nameLabel.isHidden = true
                    self?.createdLabel.isHidden = true
                    let label = UILabel(frame: CGRect(x: (self?.view.frame.width ?? 40-200)/2, y: (self?.view.frame.height ?? 100-40)/2, width: 200, height: 40))
                    label.text = error.description
                    self?.view.addSubview(label)
                    self?.hideActivityIndicator(actView: self!.activityView)
                }
                
            }
        }
        
    }
    
    func dateFromTimestamp(time: Int)->String {
          let time = Double(time)/1000.0
          let myDate = NSDate(timeIntervalSince1970: time)
          
          let dayTimePeriodFormatter = DateFormatter()
          dayTimePeriodFormatter.dateFormat = "MMM dd YYYY hh:mm a"
          dayTimePeriodFormatter.timeZone = NSTimeZone(name: "UTC") as TimeZone?
          
          let dateString = "Created in " + dayTimePeriodFormatter.string(from: myDate as Date)
          return dateString
      }
}
