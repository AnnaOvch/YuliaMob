

import UIKit

class AreasTableViewController: UITableViewController {
    
    

    var areas: [Area]?
    
    let activityView = UIActivityIndicatorView(style: .medium)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getAreas()
        let nib = UINib(nibName: "AreaTableViewCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "areaCell")
        tableView.allowsSelection = false
     
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        if let count = areas?.count {
            return count
        }
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return areas?.count ?? 0
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "areaCell") as! AreaTableViewCell
        let area = self.areas![indexPath.row]
        cell.configureCell(area: area)
        return cell
    }
  
}
extension AreasTableViewController {
    func getAreas() {
        self.showActivityIndicatory(actView: activityView)
        Network.shared.getAreas { [weak self] (result) in
            switch result{
            case .success(let areaArr):
                print("success")
                DispatchQueue.main.async {
                    self?.areas = areaArr
                    self?.tableView.reloadData()
                    self?.hideActivityIndicator(actView: self!.activityView)
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    self?.areas = nil
                    self?.tableView.reloadData()
                    self?.hideActivityIndicator(actView: self!.activityView)
                }
                
            }
        }
    }
}
