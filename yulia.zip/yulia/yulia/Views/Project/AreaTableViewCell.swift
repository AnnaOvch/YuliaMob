
import UIKit

class AreaTableViewCell: UITableViewCell {
    
    @IBOutlet weak var created: UILabel!
    @IBOutlet weak var  discription:  UILabel!
    @IBOutlet weak var culture:  UILabel!
    @IBOutlet weak var  observationData:  UILabel!

    @IBOutlet weak var areaView: UIView! {
        didSet {
            areaView.layer.cornerRadius = areaView.frame.height/3
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configureCell(area: Area) {
        self.created.text = dateFromTimestamp(time: area.created)
        self.discription.text = area.description
        self.culture.text = area.culture
        self.observationData.text = area.observationData
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func dateFromTimestamp(time: Int)->String {
           let time = Double(time)/1000.0
           let myDate = NSDate(timeIntervalSince1970: time)
           
           let dayTimePeriodFormatter = DateFormatter()
           dayTimePeriodFormatter.dateFormat = "MMM dd YYYY hh:mm a"
           dayTimePeriodFormatter.timeZone = NSTimeZone(name: "UTC") as TimeZone?
           
           let dateString = dayTimePeriodFormatter.string(from: myDate as Date)
           return dateString
       }
       
    
}
