
import UIKit

class CulturesProjectTableViewController: UITableViewController {
    
     var cultures: [Culture]?

    let activityView = UIActivityIndicatorView(style: .medium)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let nib = UINib(nibName: "CultureTableViewCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: "cultureCell")
        tableView.allowsSelection = false
        getcultures()
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let count = cultures?.count {
            return count
        }
        return 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "cultureCell") as! CultureTableViewCell
        let culture = self.cultures?[indexPath.row]
        cell.configure(culture: culture!)
        return cell
    }


}

extension CulturesProjectTableViewController {
    func getcultures () {
        self.showActivityIndicatory(actView: activityView)
        Network.shared.getProjectCultures {[weak self] (result) in
            switch result {
            case .success(let culrArr):
                DispatchQueue.main.async {
                    self?.cultures = culrArr
                    print(self?.cultures)
                    self?.tableView.reloadData()
                    self?.hideActivityIndicator(actView: self!.activityView)
                }
            case .failure(let error):
                switch error {
                case .noCulture:
                    self?.hideActivityIndicator(actView: self!.activityView)
                    self?.showAlert(alertText: error.description, alertAction: "ok", handler: nil)
                default:
                    self?.hideActivityIndicator(actView: self!.activityView)
                    self?.showAlert(alertText:"error with back", alertAction: "ok", handler: nil)
                }
            }
        }
    }
}
