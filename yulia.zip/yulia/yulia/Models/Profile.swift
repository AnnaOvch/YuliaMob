

import Foundation

struct User: Codable {
    let id: Int
    let username: String
    let lastName: String
    let firstName: String
    let email: String
    let registrationDate: Int
    let admin: Bool
}
