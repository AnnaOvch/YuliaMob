
import Foundation

struct Constants {
    static var globalToken: String?
    
}
