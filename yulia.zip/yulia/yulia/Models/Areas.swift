
import Foundation
struct Area: Codable {
    var created: Int
    var description: String
    var culture: String?
    var observationData: String?
}
