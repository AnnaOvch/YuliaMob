

import Foundation

var globalToken: String?
//var globalUser

struct UserLogIn: Codable {
    var username: String
    var token: String
    
}

