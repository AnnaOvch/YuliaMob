
import Foundation

struct Culture: Codable {
    var name: String
    var description: String
   var plantDivision: String
    var project : Int
}
struct CultureArr: Codable {
    var cultures: [Culture]
}
