

import UIKit
extension UIViewController {
    
    func showAlert(alertText : String, alertAction : String?, handler:((UIAlertAction) -> Void)?) {
        var completion: ((UIAlertAction) -> Void)? = nil
        if let handler = handler {
            completion = handler
        }
        let alert = UIAlertController(title: alertText, message: nil, preferredStyle: .alert)
        if let action = alertAction {
            alert.addAction(UIAlertAction(title: action, style: .default, handler: completion))
        }
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func dismissKey()
    {
    let tap: UITapGestureRecognizer = UITapGestureRecognizer( target: self, action: #selector(UIViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    @objc func dismissKeyboard()
    {
    view.endEditing(true)
    }

    func showActivityIndicatory(actView:UIActivityIndicatorView) {
         for subview in view.subviews where !(view is UIActivityIndicatorView) {
             subview.isHidden = true
         }
          actView.center = self.view.center
          actView.startAnimating()
          self.view.addSubview(actView)
      }
    func hideActivityIndicator(actView:UIActivityIndicatorView) {
          for subview in view.subviews where !(view is UIActivityIndicatorView) {
              subview.isHidden = false
          }
          actView.isHidden = true
          actView.stopAnimating()
          
      }

}


protocol StoryboardLoadable: class {
    static var storyboardName: String { get }
}

extension StoryboardLoadable where Self: UIViewController {
    static func instance() -> Self {
        let storyboard = UIStoryboard(name: storyboardName, bundle: nil)
        
        guard let viewController = storyboard.instantiateInitialViewController() as? Self else {
            fatalError(String(describing: Self.self) + "not found in \(storyboardName)")
        }
        
        return viewController
    }
}

extension UITableView {
    func setEmptyView(title: String, message: String) {
        let emptyView = UIView(frame: CGRect(x: self.center.x, y: self.center.y, width: self.bounds.size.width, height: self.bounds.size.height))
        let titleLabel = UILabel()
        let messageLabel = UILabel()
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.textColor = UIColor.black
        titleLabel.font = UIFont(name: "HelveticaNeue-Bold", size: 18)
        messageLabel.textColor = UIColor.lightGray
        messageLabel.font = UIFont(name: "HelveticaNeue-Regular", size: 17)
        emptyView.addSubview(titleLabel)
        emptyView.addSubview(messageLabel)
        titleLabel.centerYAnchor.constraint(equalTo: emptyView.centerYAnchor).isActive = true
        titleLabel.centerXAnchor.constraint(equalTo: emptyView.centerXAnchor).isActive = true
        messageLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 20).isActive = true
        messageLabel.leftAnchor.constraint(equalTo: emptyView.leftAnchor, constant: 20).isActive = true
        messageLabel.rightAnchor.constraint(equalTo: emptyView.rightAnchor, constant: -20).isActive = true
        titleLabel.text = title
        messageLabel.text = message
        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center
        // The only tricky part is here:
        self.backgroundView = emptyView
        self.separatorStyle = .none
    }
    func restore() {
        self.backgroundView = nil
        self.separatorStyle = .singleLine
    }
}
